<head>
	<Title>Index: SouthBay Crafters</Title>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<script src="Js/jquery-3.6.0.js"></script>
	
	<link rel="stylesheet" href="style.css">
	<link rel="stylesheet" href="../style.css">
	<link rel="stylesheet" href="../../style.css">
	<link href="https://fonts.googleapis.com/css2?family=Pacifico&display=swap" rel="stylesheet">
	<script src="https://use.fontawesome.com/3aa07dfa6e.js"></script>
	
			
</head>
<header class="tab-desk">
			<h1>South Bay Crafters</h1>
			
		</header>