<nav class="tab-desk">

			<ul>
				<li><a href="<?php echo $app_path . 'index.php?action=view_home' ?>">Home</a></li>
				<li><a href="<?php echo $app_path . 'catalog/index.php' ?>">Products</a></li>				 
				
                <li><a href="<?php echo $app_path . 'account/index.php' ?>">Customers</a></li>
				
				<li><a href="<?php echo $app_path . 'admin/index.php' ?>">Admin</a></li>
				
								
			</ul>			
</nav>