<footer>
			
				<p>&copy;2021 South Bay Crafters.</p>
                <?php $date = new DateTime(); 
                echo $date->format('m-d-Y H:i');?>
</footer>