<main>
<p id="welcome"> Make your loved ones feel extra special in this festive season with our unique hand crafted gifts.  </p>
<p> Our Newest Product</p>

</main>