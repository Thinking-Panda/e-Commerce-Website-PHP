<?php 
require_once('../util/main.php');
require_once('util/secure_conn.php');

require_once('model/customer_db.php');
require_once('model/address_db.php');
require_once('model/order_db.php');
require_once('model/product_db.php');

require_once('model/fields.php');
require_once('model/validate.php');
$action = filter_input(INPUT_POST, 'action');
if ($action == NULL) {
    $action = filter_input(INPUT_GET, 'action');
    if ($action == NULL) {        
        $action = 'view_login';
        //if (isset($_SESSION['user'])) {
            //$action = 'view_account';
        //}
    }
} 

switch($action){
    case 'view_home':
        redirect('../index.php');
        break;
	case 'view_login':
        // Clear login data
        $email = '';
        $password = '';
        $password_message = '';
        
        include ('account_login_register.php');
        break;
    case 'login':
        $email = filter_input(INPUT_POST, 'email');
        $password = filter_input(INPUT_POST, 'password');
        
        // Validate user data
        //$validate->email('email', $email);
        //$validate->text('password', $password, true, 6, 30);        

        // If validation errors, redisplay Login page and exit controller
        //if ($fields->hasErrors()) {
           // include 'account/account_login_register.php';
           // break;
       // }
        
        // Check email and password in database
        if (is_valid_customer_login($email, $password)) {
            $_SESSION['user'] = get_customer_by_email($email);
        } else {
            $password_message = 'Login failed. Invalid email or password.';
            include 'account/account_login_register.php';
            break;
        }
    
        // If necessary, redirect to the Checkout app
        // Redirect to the Checkout application
        if (isset($_SESSION['checkout'])) {
            unset($_SESSION['checkout']);
            redirect('../checkout');
        } else {
           
            redirect('../catalog/index.php');
        }        
        break;
    case 'view_account':
        $customer_name = $_SESSION['user']['firstName'] . ' ' .
                            $_SESSION['user']['lastName'];
        $email = $_SESSION['user']['emailAddress'];        

        $shipping_address = get_address($_SESSION['user']['shipAddressID']);
        $billing_address = get_address($_SESSION['user']['billingAddressID']);        

        $orders = get_orders_by_customer_id($_SESSION['user']['customerID']);
        if (!isset($orders)) {
            $orders = array();
        }        
        include 'account_view.php';
        break;    
    case 'view_register':
        // Clear user data
        $email = '';
        $first_name = '';
        $last_name = '';
        $ship_line1 = '';
        $ship_line2 = '';
        $ship_city = '';
        $ship_state = '';
        $ship_zip = '';
        $ship_phone = '';
        $use_shipping = '';
        $bill_line1 = '';
        $bill_line2 = '';
        $bill_city = '';
        $bill_state = '';
        $bill_zip = '';
        $bill_phone = '';
        
        include ('account_register.php');
        break;   
    case 'register':
        // Store user data in local variables
        $email = filter_input(INPUT_POST, 'email');
        $password_1 = filter_input(INPUT_POST, 'password_1');
        $password_2 = filter_input(INPUT_POST, 'password_2');
        $first_name = filter_input(INPUT_POST, 'first_name');
        $last_name = filter_input(INPUT_POST, 'last_name');
        $ship_line1 = filter_input(INPUT_POST, 'ship_line1');
        $ship_line2 = filter_input(INPUT_POST, 'ship_line2');
        $ship_city = filter_input(INPUT_POST, 'ship_city');
        $ship_state = filter_input(INPUT_POST, 'ship_state');
        $ship_zip = filter_input(INPUT_POST, 'ship_zip');
        $ship_phone = filter_input(INPUT_POST, 'ship_phone');
        $use_shipping = isset($_POST['use_shipping']);
        $bill_line1 = filter_input(INPUT_POST, 'bill_line1');
        $bill_line2 = filter_input(INPUT_POST, 'bill_line2');
        $bill_city = filter_input(INPUT_POST, 'bill_city');
        $bill_state = filter_input(INPUT_POST, 'bill_state');
        $bill_zip = filter_input(INPUT_POST, 'bill_zip');
        $bill_phone = filter_input(INPUT_POST, 'bill_phone');
        
        //can insert validation code   
             
              
        // Add the customer data to the database
        $customer_id = add_customer($email, $first_name,
                                    $last_name, $password_1);

        // Add the shipping address
        $shipping_id = add_address($customer_id, $ship_line1, $ship_line2,
                                    $ship_city, $ship_state, $ship_zip,
                                    $ship_phone);
        customer_change_shipping_id($customer_id, $shipping_id);

        // Add the billing address
        if ($use_shipping) {
            $billing_id = add_address($customer_id, $ship_line1, $ship_line2,
                                        $ship_city, $ship_state, $ship_zip,
                                        $ship_phone);
        } else {
            $billing_id = add_address($customer_id, $bill_line1, $bill_line2,
                                    $bill_city, $bill_state, $bill_zip,
                                    $bill_phone);
        }
        customer_change_billing_id($customer_id, $billing_id);

        // Store user data in session
        $_SESSION['user'] = get_customer($customer_id);
        
        // Redirect to the Checkout application if necessary
        if (isset($_SESSION['checkout'])) {
            unset($_SESSION['checkout']);
            redirect('../checkout');
        } else {
            redirect('.');
        }        
        break;     
}
?>