<?php include '../view/header.php'; ?>
<?php include '../view/navbar.php'; ?>
<?php 
if (!isset($password_message)) { $password_message = ''; } 
?>
<main>
    <h1>Register</h1>
    <form action="." method="post" id="register_form">

        <h2>Customer Information</h2>
        <input type="hidden" name="action" value="register">

        <label>E-Mail:</label>
        <input type="text" name="email"
                size="30">
  <br>

        <label>Password:</label>
        <input type="password" name="password_1" size="30">
       
        <br>

        <label>Retype Password:</label>
        <input type="password" name="password_2" size="30">
        <br>

        <label>First Name:</label>
        <input type="text" name="first_name"
               
               size="30">
        <br>

        <label>Last Name:</label>
        <input type="text" name="last_name"
               
               size="30">
  <br>

        <h2>Shipping Address</h2>
        <label>Address:</label>
        <input type="text" name="ship_line1"
               
               size="30">
        <br>

        <label>Line 2:</label>
        <input type="text" name="ship_line2"
               
               size="30">
        <br>

        <label>City:</label>
        <input type="text" name="ship_city"
               
               size="30">
      <br>

        <label>State:</label>
        <input type="text" name="ship_state"
               
               size="30">
       <br>

        <label>Zip Code:</label>
        <input type="text" name="ship_zip"
               
               size="30">
     <br>

        <label>Phone:</label>
        <input type="text" name="ship_phone"
               
               size="30">
        <br>

        <h2>Billing Address</h2>
        <label>&nbsp;</label>
        <input type="checkbox" name="use_shipping"
               
               size="30"> Use shipping address
        <br>

        <label>Address:</label>
        <input type="text" name="bill_line1"
               
               size="30">
        <br>

        <label>Line 2:</label>
        <input type="text" name="bill_line2"
               
               size="30">
       <br>

        <label>City:</label>
        <input type="text" name="bill_city"
               
               size="30">
       <br>

        <label>State:</label>
        <input type="text" name="bill_state"
               
               size="30">
      <br>

        <label>Zip Code:</label>
        <input type="text" name="bill_zip" size="30">
               
        <br>

        <label>Phone:</label>
        <input type="text" name="bill_phone"
               
               size="30">
        <br>

        <label>&nbsp;</label>
        <input type="submit"  value="Register">
    </form>
</main>
<?php include '../view/footer.php'; ?>