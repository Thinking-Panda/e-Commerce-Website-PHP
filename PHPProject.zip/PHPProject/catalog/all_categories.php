<?php include '../view/header.php'; ?>
<?php include '../view/navBar.php'; ?>
<main>
<?php foreach ($category_items as $category_item) : ?>
        <p>
                <img src="<?php echo '../images/'.$category_item['categoryID'].'.jpg'?>">
        <a href="<?php echo '?category_id=' . $category_item['categoryID']; ?>">
                <?php echo htmlspecialchars($category_item['categoryName']); ?>
</a>   
        </p>
        <?php endforeach; ?>

</main>

<?php include '../view/footer.php'; ?>
