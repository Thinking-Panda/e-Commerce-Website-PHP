<?php include '../view/header.php'; ?>
<?php include '../view/navBar.php'; ?>
<main>
    <!-- display product -->
    <?php include '../view/product.php'; ?>

</main>
<?php include '../view/footer.php'; ?>